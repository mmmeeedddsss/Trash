#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

bool **a;

int main()
{
	freopen("kompici.gir","r",stdin);
	freopen("kompici.cik","w",stdout);
	int n;
	scanf("%d",&n);
	a = new bool*[n];
	for( int i=0; i<n; i++ )
		a[i] = new bool[10];
	
	char lo;
	scanf("%c",&lo);
	for( int i=0; i<n; i++ )
	{
		for( int j=0; j<10; j++ )
			a[i][j] = false;
		while(true)
		{
			char temp;
			scanf("%c",&temp);
			if( temp == '\n' )
				break;
			a[i][temp-'0'] = true;
 		}
	}
	unsigned long long int counter = 0;
	for( int i=0; i<n; i++ )
		for( int j=i+1; j<n; j++ )
			for( int m=0; m<10; m++ )
				if( a[i][m] == true && a[j][m] == true )
				{
					counter++;
					break;
				}
	printf("%lld",counter);
}
