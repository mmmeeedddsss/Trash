#include<iostream>
#include<fstream>
using namespace std;

int main()
{
	int time;
	int t1,t2;
	int sabit=0, katsayi1=0, katsayi2=0;
	cin>>time>>t1;
	for( int i=0; i<t1; i++ )
	{
		int a,b;
		cin>>a>>b;
	}
}
